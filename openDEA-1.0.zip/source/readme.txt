

opendea.f90 (codigo fuente del programa proncipal)
simplex.f90 (subrutina simplex.f90, para resolver el
	     modelo de programacion lineal)