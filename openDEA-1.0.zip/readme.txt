

Contenido de carpetas:




	* bin (almacena ejecutables)

	- OpenDEA-1.0-32.exe (Ejecutable en Sistema operativo Windows a 32 bits)
	- OpenDEA-1.0 (Ejecutable en Sistema operativo Linux a 64 bits)

	* doc

	- manual.doc (manual de usuario)
	
	* source (codigo fuente de programa)

	- opendea.f90 (Codigo fuente del programa principal)
	- simplex.f90 (Codigo fuente de la subrutina)
	

	* test (ejemplo de datos de entada)

	- entrada.txt (datos de entrada para el caso de estudio)
	
